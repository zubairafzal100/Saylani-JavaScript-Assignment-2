# Saylani-JavaScript-Assignment-2
Saylani javascript assignments of 21 to 38 chapters
